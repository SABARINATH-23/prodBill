package com.prodbill.prodBill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdBillApplicationTests {

	@Test
	void contextLoads() {
	}

}
